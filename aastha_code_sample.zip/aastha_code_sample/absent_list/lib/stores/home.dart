import 'package:absent_list/repositories/models/absence.dart';
import 'package:intl/intl.dart';
import 'package:mobx/mobx.dart';

import '../repositories/repo/apis.dart';
import '../utils/constants/strings.dart';

class HomeStore with Store {
  final ApiCall apiCall = ApiCall();
  final Observable<ObservableFuture<dynamic>?> absenceModel = Observable(null);
  final Observable<ObservableFuture<dynamic>?> memberModel = Observable(null);
  ObservableList<AbsenceModel> absenceList = ObservableList<AbsenceModel>();
  ObservableList<AbsenceModel> fixedList = ObservableList<AbsenceModel>();
  Observable<bool> isLoading = Observable(false);
  dynamic response;
  List<dynamic>? response1;
  List<dynamic>? response2;
  Observable<bool> isfiltered = Observable(false);

  // Note : Call absence json data and member json data
  void init() {
    try {
      runInAction(() async {
        absenceModel.value = ObservableFuture(apiCall.absences());
        memberModel.value = ObservableFuture(apiCall.members());
        response = await apiCall.absences();
        response1 = response['payload'];
        final memberResponse = await apiCall.members();
        response2 = memberResponse['payload'];
        print(response);

        final List<dynamic> absenceJsonResponse = addName(response1, response2);
        final List<AbsenceModel> absencesData = List<AbsenceModel>.from(
            absenceJsonResponse.map((json) => AbsenceModel.fromJson(json)));
        absenceList.addAll(absencesData);
        fixedList.addAll(absenceList);
      });
    } catch (e) {
      print(e);
    }
  }

  // Note : Add name from member json to absence json
  List<dynamic> addName(dynamic absenceJson, dynamic memberJson) {
    Map<int, String> userIdToName = {
      for (var item in memberJson) item["userId"]: item["name"]
    };

    for (var item in absenceJson) {
      if (userIdToName.containsKey(item["userId"])) {
        item["name"] = userIdToName[item["userId"]];
      }
    }
    return absenceJson;
  }

  // Note : Sort absence list by type
  void shortDataByType(String type) {
    runInAction(() {
      absenceList.clear();
      absenceList = ObservableList<AbsenceModel>.of(
        fixedList.where((absence) => absence.type == type),
      );
    });
  }

  // Note : Sort absence list by start date
  void shortDataByStartDate(DateTime? startDate) {
    String formattedStartDate =
        DateFormat('yyyy-MM-dd').format(startDate ?? DateTime.now());

    runInAction(() {
      absenceList.clear();

      absenceList = ObservableList<AbsenceModel>.of(
        fixedList.where(
            (absence) => absence.startDate!.compareTo(formattedStartDate) >= 0),
      );
    });
  }

  // Note : Sort absence list by type and start date both
  void shortbyDateAndType(DateTime? date, String type) {
    shortDataByStartDate(date);
    runInAction(() {
      absenceList = ObservableList<AbsenceModel>.of(
        absenceList.where((absence) => absence.type == type),
      );
    });
  }

  // Note : Clear filters
  void clearFilter() {
    runInAction(() {
      isfiltered.value = false;
      absenceList
        ..clear()
        ..addAll(fixedList);
    });
  }

  // Note : Apply filter accroding to selected fields
  void applyFilter(DateTime? date, String? type) {
    runInAction(() => isfiltered.value = true);
    if (date != null && type != null) {
      shortbyDateAndType(date, type);
    } else if (type != null) {
      shortDataByType(type);
    } else if (date != null) {
      shortDataByStartDate(date);
    } else {
      runInAction(() => clearFilter);
    }
  }

  // Note : Convert start date till end date into no. of days
  String calculateDaysBetween(DateTime? startDate, DateTime? endDate) {
    if (startDate == null || endDate == null) return '0 ${AbsentStrings.day}';
    int days = endDate.difference(startDate).inDays + 1;
    return '$days ${AbsentStrings.day}${days > 1 ? 's' : ''}';
  }

  // Note : Return status according to rejectedAt field
  String getStatus(String? data) {
    if (data != null) {
      return AbsentStrings.approved;
    }
    return AbsentStrings.rejected;
  }

  // Note : Load more data when scroll (pagination)
  void fetchMoreData(int page) {
    try {
      runInAction(() async {
        isLoading.value = true;
        response = await callJsonData(page);
        response1 = response['payload'];
        final List<dynamic> absenceJsonResponse = addName(response1, response2);
        final List<AbsenceModel> absencesData = List<AbsenceModel>.from(
            absenceJsonResponse.map((json) => AbsenceModel.fromJson(json)));
        absenceList.addAll(absencesData);
        fixedList.addAll(absenceList);
        isLoading.value = false;
      });
    } catch (e) {
      print(e);
    }
  }

  // Note : Call json file with respect to it's page number.
  Future<dynamic> callJsonData(int page) async {
    switch (page) {
      case 1:
        return await apiCall.absences1();
      case 2:
        return await apiCall.absences2();
      case 3:
        return await apiCall.absences3();
      default:
        return await apiCall.absences();
    }
  }
}
