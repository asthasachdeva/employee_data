import 'package:json_annotation/json_annotation.dart';

part 'absence.g.dart';

@JsonSerializable(createToJson: false)
class AbsenceModel {
  int? admitterId;
  String? admitterNote;
  String? confirmedAt;
  String? createdAt;
  int? crewId;
  String? endDate;
  int? id;
  String? memberNote;
  String? rejectedAt;
  String? startDate;
  String? type;
  int? userId;
  String? name;

  AbsenceModel(
      {this.admitterId,
      this.admitterNote,
      this.confirmedAt,
      this.createdAt,
      this.crewId,
      this.endDate,
      this.id,
      this.memberNote,
      this.rejectedAt,
      this.startDate,
      this.type,
      this.userId,
      this.name});
  factory AbsenceModel.fromJson(Map<String, dynamic> json) =>
      _$AbsenceModelFromJson(json);
}
