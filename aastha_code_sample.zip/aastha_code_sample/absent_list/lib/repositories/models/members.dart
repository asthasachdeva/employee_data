import 'package:json_annotation/json_annotation.dart';

part 'members.g.dart';

@JsonSerializable(createToJson: false)
class MembersModel {
  int? crewId;
  int? id;
  String? image;
  String? name;
  int? userId;

  MembersModel({this.crewId, this.id, this.image, this.name, this.userId});

  factory MembersModel.fromJson(Map<String, dynamic> json) =>
      _$MembersModelFromJson(json);
}
