// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'absence.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AbsenceModel _$AbsenceModelFromJson(Map<String, dynamic> json) => AbsenceModel(
      admitterId: (json['admitterId'] as num?)?.toInt(),
      admitterNote: json['admitterNote'] as String?,
      confirmedAt: json['confirmedAt'] as String?,
      createdAt: json['createdAt'] as String?,
      crewId: (json['crewId'] as num?)?.toInt(),
      endDate: json['endDate'] as String?,
      id: (json['id'] as num?)?.toInt(),
      memberNote: json['memberNote'] as String?,
      rejectedAt: json['rejectedAt'] as String?,
      startDate: json['startDate'] as String?,
      type: json['type'] as String?,
      userId: (json['userId'] as num?)?.toInt(),
      name: json['name'] as String?,
    );
