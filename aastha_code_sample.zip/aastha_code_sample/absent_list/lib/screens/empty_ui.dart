import 'package:flutter/material.dart';

import '../utils/common/text.dart';
import '../utils/constants/strings.dart';

class EmptyListScreen extends StatelessWidget {
  final String title;

  const EmptyListScreen({
    super.key,
    this.title = AbsentStrings.noItemsFound,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.inbox,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            CommonText(
              title: title,
              fontWeight: FontWeight.bold,
            ),
          ],
        ),
      ),
    );
  }
}
