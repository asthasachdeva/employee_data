class AbsentStrings {
  static const String approved = 'Approved';
  static const String rejected = 'Rejected';
  static const String noItemsFound = 'No Items Found';
  static const String errorTitle = 'Oops! Something went wrong';
  static const String day = 'Day';
  static const String absentList = 'Absent List';
  static const String period = 'Period';
  static const String memberNote = 'Member Note';
  static const String admitterNote = 'Admitter Note';
  static const String filterOptions = "Filter Options";
  static const String filterbyType = 'Filter by Type';
  static const String sickness = 'Sickness';
  static const String vacation = 'Vacation';
  static const String filterbyDate = 'Filter by Date';
  static const String applyFilters = 'Apply Filters';
  static const String clearFilters = 'Clear Filters';
  static const String type = 'Type';
}
