import 'package:flutter/material.dart';

class CommonText extends StatelessWidget {
  const CommonText(
      {required this.title,
      this.fontSize,
      this.fontWeight,
      this.color,
      super.key});
  final String title;
  final double? fontSize;
  final FontWeight? fontWeight;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      maxLines: 1,
      style: TextStyle(
          fontSize: fontSize,
          fontWeight: fontWeight,
          color: color,
          overflow: TextOverflow.ellipsis),
    );
  }
}
