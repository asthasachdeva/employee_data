import 'package:absent_list/stores/home.dart';
import 'package:absent_list/utils/common/text.dart';
import 'package:absent_list/utils/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

import '../utils/constants/strings.dart';
import 'empty_ui.dart';

class HomeUI extends StatefulWidget {
  const HomeUI({required this.store, super.key});
  final HomeStore store;

  @override
  State<HomeUI> createState() => _HomeUIState();
}

class _HomeUIState extends State<HomeUI> {
  final ScrollController scrollController = ScrollController();
  bool _isFetching = false;

  @override
  void initState() {
    scrollController.addListener(_scrollListener);
    super.initState();
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (widget.store.isfiltered.value == false) {
      if (scrollController.position.pixels >=
          scrollController.position.maxScrollExtent - 100) {
        if (!widget.store.isLoading.value && !_isFetching) {
          if (widget.store.response['page'] <
              widget.store.response['total_pages']) {
            _isFetching = true;
            widget.store.fetchMoreData(widget.store.response['page']);

            // Delay flag reset to avoid rapid multiple calls
            Future.delayed(Duration(milliseconds: 200), () {
              _isFetching = false;
            });
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const CommonText(
            title: AbsentStrings.absentList,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          backgroundColor: Colors.green,
          actions: [
            IconButton(
                onPressed: () => showFilterBottomSheet(context),
                icon: const Icon(
                  Icons.filter_alt_sharp,
                  color: Colors.white,
                ))
          ],
        ),
        body: Observer(builder: (context) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: (widget.store.absenceList.isEmpty)
                ? EmptyListScreen()
                : ListView.builder(
                    controller: scrollController,
                    itemCount: widget.store.absenceList.length,
                    itemBuilder: (context, index) {
                      return absentTabs(context, index);
                    }),
          );
        }));
  }

  Widget absentTabs(BuildContext context, int index) {
    final data = widget.store.absenceList[index];
    return Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        width: MediaQuery.sizeOf(context).width,
        decoration: BoxDecoration(
          color: AbsentColors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CommonText(
                    title: data.name ?? '',
                    fontWeight: FontWeight.bold,
                  ),
                  CommonText(
                    title: widget.store.getStatus(data.rejectedAt),
                    color: widget.store.getStatus(data.rejectedAt) ==
                            AbsentStrings.approved
                        ? AbsentColors.green
                        : AbsentColors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              infoFieldWidget(
                  keyData: AbsentStrings.period,
                  valueData: widget.store.calculateDaysBetween(
                      DateTime.parse(data.startDate ?? ''),
                      DateTime.parse(data.endDate ?? ''))),
              infoFieldWidget(
                  keyData: AbsentStrings.type, valueData: data.type ?? ''),
              if (data.memberNote != '')
                infoFieldWidget(
                    keyData: AbsentStrings.memberNote,
                    valueData: data.memberNote ?? ''),
              if (data.admitterNote != '')
                infoFieldWidget(
                    keyData: AbsentStrings.admitterNote,
                    valueData: data.admitterNote ?? ''),
            ],
          ),
        ));
  }

  Widget infoFieldWidget({required String keyData, required String valueData}) {
    return Row(
      children: [
        CommonText(
          title: '$keyData :',
          fontWeight: FontWeight.w600,
        ),
        const SizedBox(
          width: 10,
        ),
        Expanded(
          child: SizedBox(
            child: CommonText(
              title: valueData,
            ),
          ),
        ),
      ],
    );
  }

  void showFilterBottomSheet(BuildContext context) {
    String? selectedType;
    DateTime? selectedDate;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(AbsentStrings.filterOptions,
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),

                  // Filter by Type
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                        labelText: AbsentStrings.filterbyType),
                    items: [AbsentStrings.sickness, AbsentStrings.vacation]
                        .map((String type) {
                      return DropdownMenuItem(value: type, child: Text(type));
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedType = value;
                        if (selectedType != null) {
                          widget.store
                              .shortDataByType(selectedType!.toLowerCase());
                        }
                      });
                    },
                  ),
                  const SizedBox(height: 16),

                  // Filter by Date
                  TextFormField(
                    decoration: const InputDecoration(
                      labelText: AbsentStrings.filterbyDate,
                      suffixIcon: Icon(Icons.calendar_today),
                    ),
                    readOnly: true,
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (pickedDate != null) {
                        setState(() {
                          selectedDate = pickedDate;
                        });
                      }
                    },
                    controller: TextEditingController(
                      text: selectedDate != null
                          ? "${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}"
                          : "",
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          widget.store.applyFilter(
                              selectedDate, selectedType?.toLowerCase());
                        },
                        child: CommonText(
                          title: AbsentStrings.applyFilters,
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                          widget.store.clearFilter();
                        },
                        child: CommonText(
                          title: AbsentStrings.clearFilters,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
