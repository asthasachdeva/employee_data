package com.example.absent_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
