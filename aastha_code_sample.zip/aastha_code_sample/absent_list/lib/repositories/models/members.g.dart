// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'members.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MembersModel _$MembersModelFromJson(Map<String, dynamic> json) => MembersModel(
      crewId: (json['crewId'] as num?)?.toInt(),
      id: (json['id'] as num?)?.toInt(),
      image: json['image'] as String?,
      name: json['name'] as String?,
      userId: (json['userId'] as num?)?.toInt(),
    );
