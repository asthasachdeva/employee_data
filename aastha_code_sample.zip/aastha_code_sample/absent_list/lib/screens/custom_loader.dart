import 'package:absent_list/screens/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:mobx/mobx.dart';

import '../stores/home.dart';
import '../utils/constants/strings.dart';
import 'empty_ui.dart';

class CustomLoader extends StatefulWidget {
  const CustomLoader({super.key});

  @override
  State<CustomLoader> createState() => _CustomLoaderState();
}

class _CustomLoaderState extends State<CustomLoader> {
  final HomeStore store = HomeStore();
  @override
  void initState() {
    store.init();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print(store.absenceModel.value?.status);
    return Scaffold(
      body: Observer(
        builder: (context) {
          switch (store.absenceModel.value?.status ?? FutureStatus.pending) {
            case FutureStatus.pending:
              return Center(child: CircularProgressIndicator());
            case FutureStatus.rejected:
              return EmptyListScreen(
                title: AbsentStrings.errorTitle,
              );
            case FutureStatus.fulfilled:
              return HomeUI(
                store: store,
              );
          }
        },
      ),
    );
  }
}
