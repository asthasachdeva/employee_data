import 'dart:convert';

import 'package:flutter/services.dart';

const absencesPath = 'absence.json';
const absencesPath1 = 'absence1.json';
const absencesPath2 = 'absence2.json';
const absencesPath3 = 'absence3.json';
const membersPath = 'members.json';

class ApiCall {
  Future<dynamic> readJsonFile(String path) async {
    try {
      String content = await rootBundle.loadString(path);
      Map<String, dynamic> data = jsonDecode(content);
      return data;
    } catch (e) {
      return '';
    }
  }

  Future<dynamic> absences() async {
    try {
      return await readJsonFile(absencesPath);
    } catch (e) {
      return '';
    }
  }

  Future<dynamic> absences1() async {
    try {
      return await readJsonFile(absencesPath1);
    } catch (e) {
      return '';
    }
  }

  Future<dynamic> absences2() async {
    try {
      return await readJsonFile(absencesPath2);
    } catch (e) {
      return '';
    }
  }

  Future<dynamic> absences3() async {
    try {
      return await readJsonFile(absencesPath3);
    } catch (e) {
      return '';
    }
  }

  Future<dynamic> members() async {
    return await readJsonFile(membersPath);
  }
}
