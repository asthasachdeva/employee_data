import 'package:flutter/material.dart';

class AbsentColors {
  static const Color white = Color.fromARGB(255, 199, 197, 197);
  static const Color green = Color.fromARGB(255, 9, 135, 9);
  static const Color red = Color.fromARGB(255, 247, 0, 0);
}
